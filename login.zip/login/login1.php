<!doctype html>
<!--
  Material Design Lite
  Copyright 2015 Google Inc. All rights reserved.

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License
-->
<?php
	if(isset($email['id'])){
	session_start();
	$_SESSION['nome'];
	}
?>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="Introducing Lollipop, a sweet new take on Android.">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
		<title>ABBA Condomínios</title>
		<link rel="shortcut icon" type="image/png" href="../img/office.png"> <!---- Icone da aba ---->
		<!-- Páginas de Estilo -->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="../css/material.min.css">
		<link rel="stylesheet" href="../css/estilo.css">
		<script src="../js/index.js"></script> <!---- Script---->
		<script src="../js/JspGF.js"></script>
		<script type="text/javascript" src="../js/jquery.balanced-gallery.js"></script>
		<style>
			#view-source {
				position: fixed;
				display: block;
				right: 0;
				bottom: 0;
				margin-right: 40px;
				margin-bottom: 40px;
				z-index: 900;
			}
			.container{
				width:350px;
				margin:0 auto;
				margin-bottom:80px;
				margin-top:80px;
				background-color:#EEEEEE;
				border-radius:10px;
			}
			.button{
				width:305px;
				height:40px;
				color:white;
				background-color:#152655;
				margin-bottom:10px;
				font-size:15px;
			}
			#left{
				margin-left:15px;
				text-align:center;
			}
			#ou{
				  color: black;
				  padding: 7px;
				  border-color:#162955;
				  cursor: pointer;
				  width: 90%;
				  margin-left: 5px;
				  margin-bottom:5px;
				  text-align:center;
			}
			#tamanho{
				margin-bottom:50px;
			}
			body{
				background-image:URL('../img/predio.png');
				background-repeat:no-repeat;
				background-size:cover;
			}
		</style>
	</head>
	<body>
		<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
			<div class="android-content mdl-layout__content"> </div>
			<div class="android-drawer mdl-layout__drawer"> <!---- MENU HAMBURGUER---->
				<span class="mdl-layout-title">
				  <img class="image" src="../img/1.png">
				</span>
				<nav class="mdl-navigation">
				  <a class="mdl-navigation__link" href="../login/login.html"> <i class="material-icons">person</i>&nbsp&nbspLogin</a>
				  <a class="mdl-navigation__link" href="../galeria/galeria.html"> <i class="material-icons">perm_media</i>&nbsp&nbspGaleria</a>
				  <a class="mdl-navigation__link" href="../noticias/noticias.html"><img src="../img/newspaper.png">&nbsp&nbspNotícias</a>
				  <a class="mdl-navigation__link" href="../duvidas/duvidas.html"><i class="material-icons">help</i>&nbsp&nbspDúvidas Frequentes</a>
				  <a class="mdl-navigation__link" href=""><i class="material-icons">assessment</i>&nbsp&nbspEnquetes</a>
				  <a class="mdl-navigation__link" href="../seguranca/seguranca.html"><i class="material-icons">lock</i>&nbsp&nbspSegurança</a>
				  <a class="mdl-navigation__link" href=""><i class="material-icons">info</i>&nbsp&nbspMural de Avisos</a>
				  <a class="mdl-navigation__link" href="../index.html"><i class="material-icons">home</i>&nbsp&nbspPlanta</a>
				</nav>
			</div> <!---- FIM MENU HAMBURGUER---->
			<div class="container mdl-shadow--2dp through mdl-shadow--16dp">
				<h3 class="mdl-color-text--indigo-900" id="left"> <!---- INÍCIO TIPO DE USUÁRIO ---->
					Login
				</h3>
				<form method="POST" action="conferelogin.php">
					<div class="mdl-grid">
						<div class="mdl-cell mdl-cell--12-col">
							<h6 class="mdl-color-text--indigo-900">E-mail</h6>
							<div class="mdl-textfield mdl-js-textfield">
								<input class="mdl-textfield__input" type="email" id="email1" name="email">
								<label class="mdl-textfield__label mdl-color-text--blue-grey-500" for="email1">Entre com seu email...</label>
							</div>
						</div>
						<div class="mdl-cell mdl-cell--12-col">
							<h6 class="mdl-color-text--indigo-900">Senha</h6>
							<div class="mdl-textfield mdl-js-textfield">
								<input class="mdl-textfield__input" type="password" id="senha1" name="senha" maxlength="8">
								<label class="mdl-textfield__label mdl-color-text--blue-grey-500" for="senha1">Entre com a senha...</label>
							</div>
						</div>
						<div class="mdl-cell mdl-cell--12-col">
							<input type="submit" name="login" value="entrar" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect  button">
						</div>
						<div id="ou">Ou</div>
						<div class="mdl-cell mdl-cell--12-col">
							<button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect  button">
								<i class="material-icons">account_circle</i>&nbsp&nbsp Entrar com facebook
							</button>
						</div>
					</div>
					<div class="mdl-grid">
						<div class="mdl-cell mdl-cell--6-col"></div>
						<div class="mdl-cell mdl-cell--6-col">
							<a  href="senha.html"><span align="left" class="mdl-color-text--indigo-700">Esqueceu a senha?</span></a>
						</div>
					</div>
				</form>
			</div>
		</div>
		<script src="../js/material.min.js"></script>
	</body>
</html>
       