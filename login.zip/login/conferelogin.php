<?php
include "conexao.php";
	$nomeRecebido = $_POST['email'];
	$senhaRecebida = md5($_POST['senha']);
	
	$sql = "SELECT * FROM clientes   WHERE email='$nomeRecebido' AND senha='$senhaRecebida'";
	$receber = $conectar -> prepare($sql);
	$receber -> execute();
	$tucano = $receber -> rowCount();
	
	if($tucano == 1){		
		foreach($receber as $email){}		
		if(isset($email['id'])){
			session_start();
			$_SESSION['id'] = $email['id'];
			$_SESSION['email'] = $email['email'];
			$_SESSION['nome'] = $email['nome_razao'];
			$_SESSION['senha'] = $email['senha'];
			$_SESSION['logado'] = 1;
			$_SESSION['tipo'] = $email['tipo'];
			if($_SESSION['tipo'] == 1 ){
				header("Location: ../adm/index.php");
			}
			else{
				header("Location: ../cond/index.php");
			}
		}
	}
	else 
			{
		echo "
			<script>
				alert('E-mail e/ou senha inválidos');
				window.location.href='login1.php';
			</script>";
		} 
	/*else  :(($nomeRecebido=='adm17@gmail.com')&&($senhaRecebida=='90e71616cdff419af8effe3f276a0d05')){
		
	}*/
?>