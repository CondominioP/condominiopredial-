<?php

	try{ //tente
		$conectar = new PDO("mysql:host=localhost;dbname=abbacondominio","root","");
		//echo "Conexão efetuada com sucesso";
	} 
	catch(PDOException $e){ //Bloco correspondente ao try	
		// verificar var_dump($e);
		// verificar método echo $e->getCode(); 
		echo $e->getMessage(); //método amplamente utilizado		
	}
?>	
